# AI Resume & Job Description Matcher

A beginner-friendly NLP web application that compares resume text with a job description and reports:
- TF-IDF cosine similarity score
- Skills detected in both texts
- Job-description skills not detected in the resume
- Practical suggestions for reviewing the match
- A downloadable plain-text summary

## Tech stack
- Python
- Streamlit
- scikit-learn
- TF-IDF vectorization
- Cosine similarity

## Run locally

1. Install Python 3.10 or newer.
2. Open a terminal in this project folder.
3. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

4. Start the app:

   ```bash
   streamlit run app.py
   ```

## Deploy and share
1. Create a new public repository on GitHub.
2. Upload `app.py`, `requirements.txt`, and `README.md`.
3. Open [Streamlit Community Cloud](https://share.streamlit.io/), sign in with GitHub, and deploy the repository using `app.py` as the entry point.

See the [official Streamlit deployment guide](https://docs.streamlit.io/deploy) for current instructions.

## How it works
1. TF-IDF converts resume and job-description text into weighted word/phrase vectors.
2. Cosine similarity measures the angle-based similarity between the vectors.
3. A small transparent keyword list identifies common AI/data skills and compares the overlap.

## Limitations and responsible use
- Similarity is a text-overlap measure, not a probability of getting hired.
- Keyword detection is intentionally simple and may miss synonyms or context.
- Do not use this demo as an automated hiring or rejection system.
- Add a skill to your resume only when it accurately reflects your abilities.

## Future improvements
- Semantic embeddings for synonym-aware matching
- Resume PDF/DOCX upload and text extraction
- Unit tests and a larger skill taxonomy
- Evaluation against a manually labelled test set
