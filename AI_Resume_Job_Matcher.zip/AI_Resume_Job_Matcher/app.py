import re
import streamlit as st
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

st.set_page_config(page_title="AI Resume & Job Matcher", page_icon="🤖", layout="wide")

st.title("🤖 AI Resume & Job Description Matcher")
st.caption("An explainable NLP project that compares a resume with a job description.")

with st.sidebar:
    st.header("About this project")
    st.write("Uses TF-IDF and cosine similarity to estimate textual alignment between a resume and a job description.")
    st.info("This is a learning/demo tool, not a hiring decision system. Similarity is not the same as candidate quality.")

resume_text = st.text_area(
    "Paste resume text",
    height=260,
    placeholder="Paste your resume text here..."
)
jd_text = st.text_area(
    "Paste job description",
    height=220,
    placeholder="Paste the job description here..."
)

COMMON_SKILLS = [
    "python", "sql", "machine learning", "deep learning", "nlp",
    "generative ai", "llm", "prompt engineering", "pandas", "numpy",
    "scikit-learn", "tensorflow", "pytorch", "streamlit", "api",
    "git", "power bi", "data visualization", "data preprocessing",
    "feature engineering", "statistics", "data analysis", "aws",
    "azure", "docker", "rag", "vector database", "computer vision"
]

def clean_text(text):
    text = text.lower()
    text = re.sub(r"[^a-z0-9+#.\s-]", " ", text)
    return re.sub(r"\s+", " ", text).strip()

def extract_skills(text):
    lowered = clean_text(text)
    return sorted(skill for skill in COMMON_SKILLS if skill in lowered)

if st.button("Analyze Match", type="primary", use_container_width=True):
    if not resume_text.strip() or not jd_text.strip():
        st.warning("Please enter both resume text and job description.")
    else:
        vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
        matrix = vectorizer.fit_transform([resume_text, jd_text])
        score = float(cosine_similarity(matrix[0:1], matrix[1:2])[0][0] * 100)

        resume_skills = set(extract_skills(resume_text))
        jd_skills = set(extract_skills(jd_text))
        matched = sorted(resume_skills & jd_skills)
        missing = sorted(jd_skills - resume_skills)

        col1, col2, col3 = st.columns(3)
        col1.metric("Text similarity", f"{score:.1f}%")
        col2.metric("Skills matched", len(matched))
        col3.metric("JD skills detected", len(jd_skills))

        st.subheader("Similarity overview")
        st.progress(int(round(score)))
        st.caption("The score measures text similarity with TF-IDF; it does not predict interview or job success.")

        left, right = st.columns(2)
        with left:
            st.subheader("Skills found in both")
            if matched:
                st.write(", ".join(f"`{skill}`" for skill in matched))
            else:
                st.write("No overlap detected from the built-in skill list.")
        with right:
            st.subheader("JD skills not detected in resume")
            if missing:
                st.write(", ".join(f"`{skill}`" for skill in missing))
            else:
                st.write("No missing skills detected from the built-in skill list.")

        st.subheader("Suggestions")
        if missing:
            st.write("Review the missing skills and add them only if you genuinely have that experience.")
        if score < 20:
            st.write("The resume and job description use different wording or focus on different topics. Tailor your summary and project bullets to the role where accurate.")
        elif score < 45:
            st.write("There is some textual overlap. Consider aligning your project descriptions and skills with the role's relevant requirements.")
        else:
            st.write("There is a reasonable amount of textual overlap. Check that your resume gives concrete evidence for the relevant skills.")

        st.download_button(
            "Download analysis summary",
            data=(
                f"AI Resume & Job Matcher Summary\n"
                f"Text similarity: {score:.1f}%\n"
                f"Matched skills: {', '.join(matched) if matched else 'None detected'}\n"
                f"JD skills not detected: {', '.join(missing) if missing else 'None detected'}\n"
                f"\nNote: Similarity is not a hiring recommendation.\n"
            ),
            file_name="match_summary.txt",
            mime="text/plain"
        )

st.divider()
st.caption("Built with Python, Streamlit, scikit-learn, TF-IDF, and cosine similarity.")
